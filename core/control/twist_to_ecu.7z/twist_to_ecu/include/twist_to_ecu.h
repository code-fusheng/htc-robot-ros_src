
#include <ros/ros.h>
#include <geometry_msgs/TwistStamped.h>
#include <can_msgs/ecu.h>

class twist_to_ecu
{

public:

    twist_to_ecu(ros::NodeHandle &nh, ros::NodeHandle &private_nh);
    ~twist_to_ecu();

    void run();

private:

    ros::NodeHandle nh, private_nh;

};
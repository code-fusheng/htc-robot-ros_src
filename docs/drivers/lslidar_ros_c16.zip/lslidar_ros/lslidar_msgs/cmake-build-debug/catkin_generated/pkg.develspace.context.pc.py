# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/ls-lqm/Desktop/c16_3.0/src/lslidar_ros/lslidar_msgs/cmake-build-debug/devel/include".split(';') if "/home/ls-lqm/Desktop/c16_3.0/src/lslidar_ros/lslidar_msgs/cmake-build-debug/devel/include" != "" else []
PROJECT_CATKIN_DEPENDS = "message_runtime;std_msgs;sensor_msgs".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "lslidar_msgs"
PROJECT_SPACE_DIR = "/home/ls-lqm/Desktop/c16_3.0/src/lslidar_ros/lslidar_msgs/cmake-build-debug/devel"
PROJECT_VERSION = "1.2.0"
